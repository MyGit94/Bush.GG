

// 상세보기 버튼 클릭시 상세보기 버튼이 180도 회전 , 상세보기 컨텐츠가 아래로 출력

let detailViews = document.querySelectorAll(".record_detail_bt");
let detail = document.querySelectorAll(".record_detail_wrap");

detailViews.forEach((view, index) => {
  view.addEventListener("click", () => {
    detail[index].classList.toggle("on");
    detailViews[index].classList.toggle("on");
  });
});



// 같이한 플레이어 :: 소환사 네임이 7자리가 넘으면 6자리만 표기하고 나머지는 ..으로 표기하는 기능

let userName = document.querySelectorAll(".user_name_text");

userName.forEach((element) => {
  let length = element.textContent.length;
  // 글자길이가 7자리 이상넘으면 
  if(length >= 7){
    // 글자를 6개까지만 표기하고 나머지는 ... 으로 표시
    element.textContent = element.textContent.substring(0,6) + "...";
  }
});





// 데미지차트에 마우스 호버시 가한데미지 , 받은데미지에 설명칸을 출력하는 기능

let dmgCharts = document.querySelectorAll(".push_chartbar");
let getCharts = document.querySelectorAll(".get_chartbar");
let dmgHovers = document.querySelectorAll("#dmg_chart_info");
let getHovers = document.querySelectorAll("#get_chart_info");

// 상세보기 리스트 :: 데미지 막대 차트 부분을 호버시 설명문구가 나오게 출력
dmgCharts.forEach((chart, index) => {
  chart.addEventListener("mouseenter", () => {
    dmgHovers[index].style.opacity = "1";
  });

  // 마우스 호버 안했을때 사라지게
  chart.addEventListener("mouseleave", () => {
    dmgHovers[index].style.opacity = "0";
  });
});

// 받은 데미지 부분 :: 마우스 호버시 설명문구 출력
getCharts.forEach((chart, index) => {
  chart.addEventListener("mouseenter", () => {
    getHovers[index].style.opacity = "1";
  });

  // 받은 데미지 부분 :: 마우스 미호버시 설명문구 사라짐
  chart.addEventListener("mouseleave", () => {
    getHovers[index].style.opacity = "0";
  });
});

